package client;

import BankServices.AccountServices;
import BankServices.BankUsers;
import Model.BankClient;
import Model.User;
import exceptions.InvalidUserAndPassword;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class BankClients {
    public static void main(String[] args) {
        //Initializez scanner pt a prelua info de la tastatura , modelul de user,si serviciile necesare verificarii
        Scanner scanner = new Scanner(System.in);
        BankUsers users = new BankUsers();
        AccountServices accountServices = new AccountServices();
        boolean flag = false;
             //Se incarca datele despre useri si parole din fisier extern

        try (BufferedReader dirFile = new BufferedReader(new FileReader("PasswordDB.txt"))) {
            String firstString;
            int i = 0;
             // se citeste linie cu linie si folosind delimitator"-" se stocheaza valori text

            while ((firstString = dirFile.readLine()) != null) {
                Scanner scanner1 = new Scanner(firstString);
                scanner1.useDelimiter("-");
                String s = scanner1.next();
                scanner1.skip(scanner1.delimiter());
                String s2 = scanner1.next();
                // folosind cele doua valori din text se aduaga in HashMAp useri si parole
                users.addUser(i++, new User(s, s2));
                // System.out.println(firstString + " or user: " + s + " pass : " + s2);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
//        for (User us : users.getBankUsers().values()) {
//            System.out.println(us.getUser() + " and pass " + us.getPassword());
//        }
        do {
            // Se cere de la tastatura user
            System.out.println(" Please give me a user: ");
            String user = scanner.nextLine();
            try {
                // se verifica daca exista acest user in baza de date
                flag = accountServices.checkUsers(user, users.getBankUsers());
            } catch (InvalidUserAndPassword e) {
                e.getMessage();
            }
            // se cere parola de la user
            System.out.println(" Please enter your Password: ");
            String password = scanner.nextLine();
             // se verifica daca aceasta parola exista
            try {
                flag = false;
                flag = accountServices.checkPassword(user, password, users.getBankUsers());
            } catch (InvalidUserAndPassword e) {
                e.getMessage();
            }

        } while (!flag);
        System.out.println(" am ajuns la final!");
        // hardcodam 3 clienti cu toate ca si acest serviciu poate fi facut automat prin apearea unui serviciu
        BankClient client1=new BankClient("mardari","bogdan","182040182334455","MZ","478900","+40765526322","mail@gmail.com","eon");
        BankClient client2=new BankClient("popescu","mihai","182122482334455","MZ","478901","+40765526321","mail1@gmail.com","brd");
        BankClient client3=new BankClient("mardari","raluca","187101182334455","MZ","478902","+40765526324","mail2@gmail.com","scc");

        // adaugam clientii intr-o lista a bancii
        accountServices.addClient(client1);
        accountServices.addClient(client2);
        accountServices.addClient(client3);

    }
}
