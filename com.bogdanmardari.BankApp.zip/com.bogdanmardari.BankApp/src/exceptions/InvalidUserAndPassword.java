package exceptions;

public class InvalidUserAndPassword  extends Exception{
    public InvalidUserAndPassword() {
        super();
        System.out.println(" Invalid user and password. Try Again!!");
    }
}
