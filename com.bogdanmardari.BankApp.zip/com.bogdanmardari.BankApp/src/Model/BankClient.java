package Model;

public class BankClient {
    private String name;
    private String surname;
    private String CNP;
    private String CISerial;
    private String CINumber;
    private String phoneNr;
    private String emailAdress;
    private String workPlace;

    public BankClient(String name, String surname, String CNP, String CISerial, String CINumber, String phoneNr, String emailAdress, String workPlace) {
        this.name = name;
        this.surname = surname;
        this.CNP = CNP;
        this.CISerial = CISerial;
        this.CINumber = CINumber;
        this.phoneNr = phoneNr;
        this.emailAdress = emailAdress;
        this.workPlace = workPlace;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setCNP(String CNP) {
        this.CNP = CNP;
    }

    public void setCISerial(String CISerial) {
        this.CISerial = CISerial;
    }

    public void setCINumber(String CINumber) {
        this.CINumber = CINumber;
    }

    public void setPhoneNr(String phoneNr) {
        this.phoneNr = phoneNr;
    }

    public void setEmailAdress(String emailAdress) {
        this.emailAdress = emailAdress;
    }

    public void setWorkPlace(String workPlace) {
        this.workPlace = workPlace;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getCNP() {
        return CNP;
    }

    public String getCISerial() {
        return CISerial;
    }

    public String getCINumber() {
        return CINumber;
    }

    public String getPhoneNr() {
        return phoneNr;
    }

    public String getEmailAdress() {
        return emailAdress;
    }

    public String getWorkPlace() {
        return workPlace;
    }
}
