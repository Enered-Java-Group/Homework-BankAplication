package Model;

import java.util.ArrayList;

public class Bank {
    private String name;
    private ArrayList<BankClient> bank;

    public Bank(String name) {
        this.name = name;
        this.bank=new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<BankClient> getBank() {
        return bank;
    }

    public void setBank(ArrayList<BankClient> bank) {
        this.bank = bank;
    }
}
