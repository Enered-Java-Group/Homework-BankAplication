package Model;

public class Account {
    BankClient client;
    private String accountName;
    private double balance;
    private String currency;

    public Account(BankClient client, String accountName, double balance, String currency) {
        this.client = client;
        this.accountName = accountName;
        this.balance = balance;
        this.currency = currency;
    }

    public void setClient(BankClient client) {
        this.client = client;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BankClient getClient() {
        return client;
    }

    public String getAccountName() {
        return accountName;
    }

    public double getBalance() {
        return balance;
    }

    public String getCurrency() {
        return currency;
    }
}
