package BankServices;

import Model.Bank;
import Model.BankClient;
import Model.User;
import exceptions.InvalidUserAndPassword;

import java.util.HashMap;

public class AccountServices {
    Bank bank = new Bank("TRANS");

public boolean addClient(BankClient client){
    if(!bank.getBank().contains(client)){
        bank.getBank().add(client);
        System.out.println(" Client added in the system!");
        return true;
    } else{
        System.out.println(" The client already exists!");
        return false;
    }
}


    public boolean checkUsers(String user, HashMap<Integer, User> bankUsers) throws InvalidUserAndPassword {
        boolean flag = false;
        for (User userB : bankUsers.values()) {
            if (user.equals(userB.getUser())) {
                flag = true;
            }
        }
        // System.out.println(flag);
        if (flag) {
            return flag;
        } else {
            throw new InvalidUserAndPassword();
        }

    }

    public boolean checkPassword(String userBank, String passw, HashMap<Integer, User> bankUsers) throws InvalidUserAndPassword {
        boolean flag = false;
        for (User userB : bankUsers.values()) {
            if (userB.getUser().equals(userBank)) {
                if (passw.equals(userB.getPassword())) {
                    flag = true;
                }
            }

        }
        if (flag) {
            return flag;
        } else {
            throw new InvalidUserAndPassword();
        }
    }

}
