package BankServices;

import Model.User;

import java.util.HashMap;

public class BankUsers {
    HashMap<Integer, User> bankUsers;

    public BankUsers() {
        this.bankUsers=new HashMap<>();
        this.bankUsers.put(1,new User("bbb","ccc"));
    }

    public HashMap<Integer, User> getBankUsers() {
        return bankUsers;
    }

    public void setBankUsers(HashMap<Integer, User> bankUsers) {
        this.bankUsers = bankUsers;
    }
    public boolean addUser(Integer number,User user){
        if (this.bankUsers.containsKey(user)){
            System.out.println(" user "+user.getUser()+" allready exists!");
            return false;
        } else{
            this.bankUsers.put(number,user);
            return true;
        }
    }
}
